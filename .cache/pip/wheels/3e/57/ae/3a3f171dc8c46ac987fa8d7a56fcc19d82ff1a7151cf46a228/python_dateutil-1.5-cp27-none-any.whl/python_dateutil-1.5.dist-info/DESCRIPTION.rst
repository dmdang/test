The dateutil module provides powerful extensions to the standard
datetime module, available in Python 2.3+.


