A Python interface to GraphViz and the DOT language.

This package includes an interface to GraphViz [1], with classes to represent
graphs and dump them in the DOT language [2], and a parser from DOT.


[1] http://www.graphviz.org
[2] http://www.graphviz.org/doc/info/lang.html


